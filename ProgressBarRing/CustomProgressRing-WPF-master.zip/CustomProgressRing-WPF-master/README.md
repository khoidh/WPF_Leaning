# CustomProgressRing
Custom Progress ring for WPF application
