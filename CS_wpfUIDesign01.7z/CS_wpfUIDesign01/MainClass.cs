﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_wpfUIDesign01
{
    class MainClass
    {
    }
    public class TodoItem
    {
        public string Title { get; set; }
        public int Completion { get; set; }
    }
    public class TempItem
    {
        public string Title { get; set; }
    }
}
