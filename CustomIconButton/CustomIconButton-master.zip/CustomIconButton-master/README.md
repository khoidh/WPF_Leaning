# CustomIconButton
Creating a custom WPF button that accepts both vector icon and text
