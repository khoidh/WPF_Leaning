﻿
namespace Stepi.Collections.Filters
{
    /// <summary>
    /// 
    /// </summary>
    public enum StringFilterMode
    {
        /// <summary>
        /// 
        /// </summary>
        StartsWith,
        /// <summary>
        /// 
        /// </summary>
        EndsWith,
        /// <summary>
        /// 
        /// </summary>
        Contains,
        /// <summary>
        /// 
        /// </summary>
        Equals
    }
}
