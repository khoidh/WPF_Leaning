﻿
namespace Stepi.UIFilters
{
    public interface IFilterView
    {
        IUIFilterPresentationModel Model { get; }
    }
}
